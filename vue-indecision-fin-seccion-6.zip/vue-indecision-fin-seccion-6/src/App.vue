<template>
  <IndecisionView />
</template>

<script lang="ts" setup>
import IndecisionView from '@/views/IndecisionView.vue';
</script>
